#define FUNCTION 1
#define RETURNS 2
#define	TBEGIN 3
#define ENDFUNCTION 4
#define WHILE 5
#define LOOP 6
#define ENDLOOP 7
#define WRITE 8
#define READ 9
#define IF 10
#define THEN 11
#define ELSE 12
#define ENDIF 13
#define VARIABLES 14


#define ID 20
#define INT 21
#define PLUS 22
#define MINUS 23
#define TIMES 24
#define DIVIDE 25
#define LBRA 26
#define RBRA 27
#define LT 28
#define LTE 29
#define EQ 30
#define NEQ 31
#define ASSIGN 32
#define SEMI 33
#define COMMA 34
#define MAIN 35

